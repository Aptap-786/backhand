# 📱 WhatsApp OTP Gateway — Installation Guide

## Overview
Personal WhatsApp OTP detection system.  
- **Backend** → Render (Node.js + whatsapp-web.js)  
- **Frontend** → Shared Hosting (PHP + MySQL)

---

## PART 1: Backend Setup (Render)

### Step 1 — Push to GitHub
1. Create a new GitHub repo (e.g. `wa-otp-backend`)
2. Upload all files from this `backend/` folder to that repo

### Step 2 — Create Render Web Service
1. Go to [render.com](https://render.com) → **New → Web Service**
2. Connect your GitHub repo
3. Fill in:
   ```
   Name:          whatsapp-otp-gateway
   Runtime:       Node
   Build Command: npm install
   Start Command: node server.js
   Plan:          Free
   ```

### Step 3 — Set Environment Variables on Render
Go to your service → **Environment** tab → Add:

| Key | Value |
|-----|-------|
| `API_KEY` | A strong random string (e.g. `mySecretKey2024abc123`) |
| `SESSION_NAMES` | `personal` |
| `MAX_OTP_HISTORY` | `50` |
| `PORT` | `3000` |

### Step 4 — Deploy
Click **Deploy**. Wait ~3 minutes.  
Your backend URL will be: `https://whatsapp-otp-gateway-xxxx.onrender.com`

> **Note:** Copy this URL and your API_KEY — you'll need them for frontend setup.

### Step 5 — Keep Backend Awake (Free Plan)
Render free plan sleeps after 15min of inactivity.  
Use [UptimeRobot](https://uptimerobot.com) (free):
- Create a monitor → HTTP(S) → URL: `https://your-backend.onrender.com/`
- Interval: every 10 minutes

---

## PART 2: Frontend Setup (Shared Hosting)

### Option A — Easy Install (Recommended)

1. Upload all files from `frontend/` to `public_html/` (or a subfolder)
2. Open browser: `https://yourdomain.com/install.php`
3. Fill in DB credentials → click Install
4. **Delete install.php** from server after install
5. Login at `https://yourdomain.com/login.php`

### Option B — Manual Install

**Step 1 — Create MySQL Database**
- cPanel → MySQL Databases → Create DB: `otp_gateway`
- Create user, set password, assign user to DB with ALL privileges

**Step 2 — Import database.sql**
- phpMyAdmin → select your DB → Import → upload `database.sql`

**Step 3 — Edit config.php**
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_db_name');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
date_default_timezone_set('Asia/Kolkata'); // change to your timezone
```

**Step 4 — Upload files**
Upload everything from `frontend/` into `public_html/`

**Step 5 — Login**
Visit `https://yourdomain.com/login.php`  
Default: `admin` / `admin123`

---

## PART 3: Connect Frontend to Backend

1. Login → go to **Settings**
2. Fill in:
   - **Backend URL:** `https://whatsapp-otp-gateway-xxxx.onrender.com`
   - **API Key:** (same key you set on Render)
   - **Session Name:** `personal`
   - **Poll Interval:** `5`
3. Click **Save Settings**
4. Click **Test Connection** → should show ✓ Connected

---

## PART 4: Connect WhatsApp

1. Go to **Dashboard**
2. A QR code will appear
3. On your phone: **WhatsApp → Settings → Linked Devices → Link a Device**
4. Scan the QR code
5. Status will change to **Connected** ✓

---

## How It Works

```
WhatsApp Message Arrives
        ↓
Backend (Node.js) detects OTP using regex
        ↓
Stored in memory (backend)
        ↓
Frontend PHP polls /api/getotp.php every 5 seconds
        ↓
Dashboard shows latest OTP with sender + time
```

---

## API Endpoints (Direct Backend Access)

All require `?key=YOUR_API_KEY`

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/latest-otp` | Get latest detected OTP |
| GET | `/api/otp-history?limit=20` | Get last N OTPs |
| POST | `/api/clear` | Clear all OTPs from memory |
| GET | `/api/qr?session=personal` | Get QR code (base64 PNG) |
| GET | `/api/status` | Get all session statuses |
| GET | `/api/health` | Health check |

Example response:
```json
{
  "status": true,
  "otp": "482913",
  "message": "Your OTP is 482913",
  "sender": "919876543210@c.us",
  "confidence": "high",
  "detected_at": "2024-01-15T10:30:00.000Z"
}
```

---

## Multiple WhatsApp Numbers

1. On Render, set `SESSION_NAMES=personal,work,business`
2. Each session shows a separate QR code
3. Access per session: `/api/latest-otp?key=KEY&session=work`

---

## Security Checklist

- [ ] Change default password after first login
- [ ] Use a strong API key (32+ random chars)
- [ ] Delete install.php after setup
- [ ] Enable HTTPS on your hosting (.htaccess redirect included)
- [ ] Keep API key secret — never share publicly

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| QR not showing | Wait 30s, refresh dashboard. Backend may be waking up. |
| "Backend not configured" | Go to Settings and save Backend URL + API Key |
| "Backend unreachable" | Check Render service is running. Check URL has no trailing slash. |
| OTP not detected | Make sure message contains a 4-8 digit number |
| Session disconnects | WhatsApp sometimes drops linked devices. Rescan QR. |
| Render sleeping | Set up UptimeRobot to ping every 10 minutes |

---

## File Structure

```
backend/
├── server.js              Main Express server
├── whatsapp-manager.js    Multi-session WhatsApp manager
├── otp-detector.js        OTP regex detection
├── api-routes.js          All REST API routes
├── package.json           Node dependencies
├── render.yaml            Render deployment config
└── .env.example           Environment variable template

frontend/
├── install.php            One-click web installer
├── config.php             Database + app config
├── login.php              Login page
├── logout.php             Logout handler
├── dashboard.php          Main OTP dashboard
├── history.php            OTP history + DB log
├── settings.php           Backend config + password change
├── database.sql           MySQL schema (manual install)
├── .htaccess              Apache security rules
├── includes/
│   └── navbar.php         Shared sidebar navigation
├── api/
│   ├── getotp.php         Proxy: latest OTP
│   ├── history.php        Proxy: OTP history
│   ├── status.php         Proxy: session status
│   ├── qr.php             Proxy: QR code
│   ├── clear.php          Proxy: clear OTPs
│   ├── sync.php           Sync backend → DB
│   ├── purge.php          Delete all DB logs
│   └── test.php           Test backend connection
└── assets/
    ├── css/style.css      Dark admin stylesheet
    └── js/app.js          Shared JS utilities
```
